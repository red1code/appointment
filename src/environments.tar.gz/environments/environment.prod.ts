export const environment = {
    production: true,
    firebase: {
        apiKey: "AIzaSyDAG8K7lafOK2woAju1Xc2pAyOcPgyiYkQ",
        authDomain: "appointment-d19b2.firebaseapp.com",
        projectId: "appointment-d19b2",
        storageBucket: "appointment-d19b2.appspot.com",
        messagingSenderId: "192421416312",
        appId: "1:192421416312:web:2dd134628e6af94a794c8d",
        measurementId: "G-ZYYTZ4ED2Y"
    }

};